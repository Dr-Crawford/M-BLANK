
/* This are empty and is left for be compatible with building some older windows nt4/2000/2003/XP drivers */

